import "./t.css";

console.log("3...");
let c = "asdf";
console.log("44...")